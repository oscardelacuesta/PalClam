/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Mozilla Universal charset detector code.
 *
 * The Initial Developer of the Original Code is
 * Netscape Communications Corporation.
 * Portions created by the Initial Developer are Copyright (C) 2001
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *          Shy Shalom <shooshX@gmail.com>
 *          Rudi Pettazzi <rudi.pettazzi@gmail.com> (C# port)
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

using System;
using System.IO;
using System.Text;
using System.Buffers;

namespace UtfUnknown.Core.Probers;

public abstract class CharsetProber
{
    protected const float SHORTCUT_THRESHOLD = 0.95F;

    protected ProbingState state;

    // ASCII codes
    private const byte SPACE = 0x20;
    private const byte CAPITAL_A = 0x41;
    private const byte CAPITAL_Z = 0x5A;
    private const byte SMALL_A = 0x61;
    private const byte SMALL_Z = 0x7A;
    private const byte LESS_THAN = 0x3C;
    private const byte GREATER_THAN = 0x3E;

    /// <summary>
    /// Feed data to the prober
    /// </summary>
    /// <param name="buf">a buffer</param>
    /// <returns>
    /// A <see cref="ProbingState"/>
    /// </returns>
    public abstract ProbingState HandleData(ReadOnlySpan<byte> buf);

    /// <summary>
    /// Reset prober state
    /// </summary>
    public abstract void Reset();

    public abstract string GetCharsetName();

    public abstract float GetConfidence(StringBuilder status = null);

    public virtual ProbingState GetState()
    {
        return state;
    }

    public virtual void SetOption()
    {

    }

    public virtual string DumpStatus()
    {
        return string.Empty;
    }

    //
    // Helper functions used in the Latin1 and Group probers
    //
    /// <summary>
    ///
    /// </summary>
    /// <returns>filtered buffer</returns>
    protected static byte[] FilterWithoutEnglishLetters(ReadOnlySpan<byte> buf)
    {
        byte[] result;

        using (MemoryStream ms = new MemoryStream(buf.Length))
        {
            bool meetMSB = false;
            int max = buf.Length;
            int prev = 0;
            int cur = 0;

            while (cur < max)
            {
                byte b = buf[cur];

                if ((b & 0x80) != 0)
                {
                    meetMSB = true;
                }
                else if (b < CAPITAL_A || (b > CAPITAL_Z && b < SMALL_A) || b > SMALL_Z)
                {
                    if (meetMSB && cur > prev)
                    {
                        WriteSpanToStream(ms, buf.Slice(prev, cur - prev));
                        ms.WriteByte(SPACE);
                        meetMSB = false;
                    }
                    prev = cur + 1;
                }
                cur++;
            }

            if (meetMSB && cur > prev)
                WriteSpanToStream(ms, buf.Slice(prev, cur - prev));
            ms.SetLength(ms.Position);
            result = ms.ToArray();
        }
        return result;
    }

    /// <summary>
    /// Do filtering to reduce load to probers (Remove ASCII symbols,
    /// collapse spaces). This filter applies to all scripts which contain
    /// both English characters and upper ASCII characters.
    /// </summary>
    /// <returns>a filtered copy of the input buffer</returns>
    protected static byte[] FilterWithEnglishLetters(ReadOnlySpan<byte> buf)
    {
        byte[] result;

        using (MemoryStream ms = new MemoryStream(buf.Length))
        {
            bool inTag = false;
            int max = buf.Length;
            int prev = 0;
            int cur = 0;

            while (cur < max)
            {
                byte b = buf[cur];

                if (b == GREATER_THAN)
                    inTag = false;
                else if (b == LESS_THAN)
                    inTag = true;

                // it's ascii, but it's not a letter
                if ((b & 0x80) == 0 && (b < CAPITAL_A || b > SMALL_Z
                                                      || (b > CAPITAL_Z && b < SMALL_A)))
                {
                    if (cur > prev && !inTag)
                    {
                        WriteSpanToStream(ms, buf.Slice(prev, cur - prev));
                        ms.WriteByte(SPACE);
                    }
                    prev = cur + 1;
                }
                cur++;
            }

            // If the current segment contains more than just a symbol
            // and it is not inside a tag then keep it.
            if (!inTag && cur > prev)
                WriteSpanToStream(ms, buf.Slice(prev, cur - prev));
            ms.SetLength(ms.Position);
            result = ms.ToArray();
        }
        return result;
    }

    private static void WriteSpanToStream(MemoryStream stream, ReadOnlySpan<byte> buffer)
    {
#if NET8_0_OR_GREATER
        stream.Write(buffer);
#else
        byte[] rent = ArrayPool<byte>.Shared.Rent(buffer.Length);

        try
        {
            buffer.CopyTo(rent);

            stream.Write(rent, 0, buffer.Length);
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(rent);
        }
#endif
    }
}
