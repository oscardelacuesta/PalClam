﻿// CharsetDetectorTest.cs created with MonoDevelop
//
// Author:
//   Rudi Pettazzi <rudi.pettazzi@gmail.com>
//

using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using UtfUnknown.Core;
using NUnit.Framework;

namespace UtfUnknown.Tests;

public class CharsetDetectorTest
{
    [Test]
    public void TestAscii()
    {
        const string text = "The Documentation of the libraries is not complete " +
                            "and your contributions would be greatly appreciated " +
                            "the documentation you want to contribute to and " +
                            "click on the [Edit] link to start writing";
        var stream = AsciiToStream(text);
        using (stream)
        {
            var result = CharsetDetector.DetectFromStream(stream);
            Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
            Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
            Assert.That(result.Detected.HasBOM, Is.False);
        }
    }

    [Test]
    public async Task TestAsciiAsync()
    {
        const string text = "The Documentation of the libraries is not complete " +
                            "and your contributions would be greatly appreciated " +
                            "the documentation you want to contribute to and " +
                            "click on the [Edit] link to start writing";
        var stream = AsciiToStream(text);
        using (stream)
        {
            var result = await CharsetDetector.DetectFromStreamAsync(stream);
            Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
            Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
            Assert.That(result.Detected.HasBOM, Is.False);
        }
    }

    [Test]
    public void TestAscii_with_HZ_sequence()
    {
        const string text = "virtual ~{{NETCLASS_NAME}}();";
        var stream = AsciiToStream(text);
        using (stream)
        {
            var result = CharsetDetector.DetectFromStream(stream);
            Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
            Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        }
    }

    [Test]
    public async Task TestAscii_with_HZ_sequenceAsync()
    {
        const string text = "virtual ~{{NETCLASS_NAME}}();";
        var stream = AsciiToStream(text);
        using (stream)
        {
            var result = await CharsetDetector.DetectFromStreamAsync(stream);
            Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
            Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        }
    }

    private static MemoryStream AsciiToStream(string s)
    {
        return new MemoryStream(Encoding.ASCII.GetBytes(s));
    }

    [Test]
    [TestCase(1024, 1024)]
    [TestCase(2048, 2048)]
    [TestCase(20, 20)]
    [TestCase(20, 30, 10)]
    [TestCase(null, 10000)]
    [TestCase(1000000, 10000)]
    [TestCase(null, 10000, 10)]
    public void DetectFromStreamMaxBytes(int? maxBytes, int expectedPosition, int start = 0)
    {
        // Arrange
        var text = new string('a', 10000);
        var stream = AsciiToStream(text);
        stream.Position = start;

        // Act
        CharsetDetector.DetectFromStream(stream, maxBytes);

        // Assert
        Assert.That(stream.Position, Is.EqualTo(expectedPosition));
    }

    [Test]
    [TestCase(1024, 1024)]
    [TestCase(2048, 2048)]
    [TestCase(20, 20)]
    [TestCase(20, 30, 10)]
    [TestCase(null, 10000)]
    [TestCase(1000000, 10000)]
    [TestCase(null, 10000, 10)]
    public async Task DetectFromStreamMaxBytesAsync(int? maxBytes, int expectedPosition, int start = 0)
    {
        // Arrange
        var text = new string('a', 10000);
        var stream = AsciiToStream(text);
        stream.Position = start;

        // Act
        await CharsetDetector.DetectFromStreamAsync(stream, maxBytes);

        // Assert
        Assert.That(stream.Position, Is.EqualTo(expectedPosition));
    }

    [Test]
    [TestCase(0, 10, CodepageName.ASCII)]
    [TestCase(0, 100, CodepageName.UTF8)]
    [TestCase(10, 100, CodepageName.UTF8)]
    public void DetectFromByteArray(int offset, int len, string detectedCodepage)
    {
        // Arrange
        string s = "UTF-Unknown은 파일, 스트림, 그 외 바이트 배열의 캐릭터 셋을 탐지하는 라이브러리입니다." +
                   "대한민국 (大韓民國, Republic of Korea)";
        byte[] bytes = Encoding.UTF8.GetBytes(s);

        // Act
        var result = CharsetDetector.DetectFromBytes(bytes, offset, len);

        // Assert
        Assert.That(result.Detected.EncodingName, Is.EqualTo(detectedCodepage));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    [TestCase(new byte[] { 0x2B, 0x2F, 0x76, 0x38 })]
    [TestCase(new byte[] { 0x2B, 0x2F, 0x76, 0x39 })]
    [TestCase(new byte[] { 0x2B, 0x2F, 0x76, 0x2B })]
    [TestCase(new byte[] { 0x2B, 0x2F, 0x76, 0x2F })]
    [TestCase(new byte[] { 0x2B, 0x2F, 0x76, 0x38, 0x2D })]
    public void TestCaseBomUtf7(byte[] bufferBytes)
    {
        var result = CharsetDetector.DetectFromBytes(bufferBytes)
            .Detected;
        Assert.That(result.EncodingName, Is.EqualTo(CodepageName.UTF7));
        Assert.That(result.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.HasBOM, Is.True);
    }

    [Test]
    public void TestBomGb18030()
    {
        var bufferBytes = new byte[] { 0x84, 0x31, 0x95, 0x33 };
        var result = CharsetDetector.DetectFromBytes(bufferBytes)
            .Detected;
        Assert.That(result.EncodingName, Is.EqualTo(CodepageName.GB18030));
        Assert.That(result.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.HasBOM, Is.True);
    }

    [Test]
    public void TestUTF8_1()
    {
        string s = "ウィキペディアはオープンコンテントの百科事典です。基本方針に賛同し" +
                   "ていただけるなら、誰でも記事を編集したり新しく作成したりできます。" +
                   "ガイドブックを読んでから、サンドボックスで練習してみましょう。質問は" +
                   "利用案内でどうぞ。";
        byte[] buf = Encoding.UTF8.GetBytes(s);
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF8));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void TestBomUtf8()
    {
        byte[] buf = { 0xEF, 0xBB, 0xBF, 0x68, 0x65, 0x6C, 0x6C, 0x6F, 0x21 };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF8));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void DetectFromReadOnlySpan()
    {
        ReadOnlySpan<byte> buf = new byte[] { 0xEF, 0xBB, 0xBF, 0x68, 0x65, 0x6C, 0x6C, 0x6F, 0x21 };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF8));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void DetectFromReadOnlySpan_Empty()
    {
        var result = CharsetDetector.DetectFromBytes(ReadOnlySpan<byte>.Empty);
        Assert.That(result.Detected, Is.Null);
    }

    [Test]
    public void DetectFromReadOnlySpan_SlicedWithOffset()
    {
        // BOM should only be recognized when it starts at the beginning of the span,
        // not at the beginning of the underlying array.
        byte[] underlying = { 0x00, 0x00, 0x00, 0x00, 0x00, 0xEF, 0xBB, 0xBF, 0x68, 0x65, 0x6C, 0x6C, 0x6F, 0x21 };
        ReadOnlySpan<byte> slice = underlying.AsSpan(5, underlying.Length - 5);

        var result = CharsetDetector.DetectFromBytes(slice);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF8));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void DetectFromReadOnlySpan_NoBom()
    {
        string s = "ウィキペディアはオープンコンテントの百科事典です。基本方針に賛同し" +
                   "ていただけるなら、誰でも記事を編集したり新しく作成したりできます。" +
                   "ガイドブックを読んでから、サンドボックスで練習してみましょう。質問は" +
                   "利用案内でどうぞ。";
        ReadOnlySpan<byte> buf = Encoding.UTF8.GetBytes(s);

        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF8));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void Test2byteArrayBomUTF16_BE()
    {
        byte[] buf = { 0xFE, 0xFF, };

        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF16_BE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomUTF16_BE()
    {
        byte[] buf = { 0xFE, 0xFF, 0x00, 0x68, 0x00, 0x65 };

        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF16_BE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomX_ISO_10646_UCS_4_3412()
    {

        byte[] buf = { 0xFE, 0xFF, 0x00, 0x00, 0x65 };

        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.X_ISO_10646_UCS_4_3412));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomX_ISO_10646_UCS_4_2143()
    {

        byte[] buf = { 0x00, 0x00, 0xFF, 0xFE, 0x00, 0x65 };

        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.X_ISO_10646_UCS_4_2143));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void Test2byteArrayBomUTF16_LE()
    {
        byte[] buf = { 0xFF, 0xFE, };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF16_LE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomUTF16_LE()
    {
        byte[] buf = { 0xFF, 0xFE, 0x68, 0x00, 0x65, 0x00 };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF16_LE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomUTF32_BE()
    {
        byte[] buf = { 0x00, 0x00, 0xFE, 0xFF, 0x00, 0x00, 0x00, 0x68 };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF32_BE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestBomUTF32_LE()
    {
        byte[] buf = { 0xFF, 0xFE, 0x00, 0x00, 0x68, 0x00, 0x00, 0x00 };
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.UTF32_LE));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.True);
    }

    [Test]
    public void TestIssue3()
    {
        byte[] buf = Encoding.UTF8.GetBytes("3");
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void TestOutOfRange()
    {
        byte[] buf = Encoding.UTF8.GetBytes("3");
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void TestOutOfRange2()
    {
        byte[] buf = Encoding.UTF8.GetBytes("1234567890");
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1.0f));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void TestSingleChar()
    {
        byte[] buf = Encoding.UTF8.GetBytes("3");
        var result = CharsetDetector.DetectFromBytes(buf);
        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.ASCII));
        Assert.That(result.Detected.Confidence, Is.EqualTo(1));
        Assert.That(result.Detected.HasBOM, Is.False);
    }

    [Test]
    public void TestFeedEmpty()
    {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

        string s = "UTF-Unknown은 파일, 스트림, 그 외 바이트 배열의 캐릭터 셋을 탐지하는 라이브러리입니다." +
            "대한민국 (大韓民國, Republic of Korea)";

        var eucKr = Encoding.GetEncoding(CodepageName.EUC_KR);
        Assert.That(eucKr, Is.Not.Null);
        var bytes = eucKr.GetBytes(s);
        
        var charsetDetector = new TestCharsetDetector();

        // Make sure EUCKRProber is enqueued to charsetDetector.CharsetProbers
        // so feeding empty bytes may invoke EUCKRProber.HandleData
        charsetDetector.Feed(bytes);
        charsetDetector.Feed([]);
        var result = charsetDetector.DataEnd();

        Assert.That(result.Detected.EncodingName, Is.EqualTo(CodepageName.EUC_KR));
        Assert.That(result.Detected.HasBOM, Is.False);
    }
}
