﻿namespace OpenMcdf.Tests;

enum WriteMode
{
    SingleByte,
    Array,
    Span,
}

[TestClass]
public sealed class StreamTests
{
#if WINDOWS && false
    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void CreateTestStreamFiles(Version version, int length)
    {
        string directory = "Reference";
        Directory.CreateDirectory(directory);

        string fileName = Path.Combine(directory, $"TestStream_v{(int)version}_{length}.cfs");
        using var rootStorage = StructuredStorage.Storage.Create(fileName, StructuredStorage.StorageModes.AccessReadWrite | StructuredStorage.StorageModes.ShareExclusive, version == Version.V4);
        using StructuredStorage.Stream stream = rootStorage.CreateStream("TestStream");

        // Test files are filled with bytes equal to their position modulo 256
        for (int i = 0; i < length; i++)
            stream.WriteByte((byte)i);
    }
#endif

    [TestMethod]
    [DataRow("TestStream_v3_0.cfs")]
    public void OpenStream(string fileName)
    {
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        Assert.IsTrue(rootStorage.TryOpenStream("TestStream", out CfbStream? _));
        Assert.IsFalse(rootStorage.TryOpenStream(string.Empty, out CfbStream? _));

        Assert.ThrowsExactly<FileNotFoundException>(() => rootStorage.OpenStream(string.Empty));

        using CfbStream stream = rootStorage.OpenStream("TestStream");
        Assert.AreEqual("TestStream", stream.EntryInfo.Name);
    }

    [TestMethod]
    [DataRow("TestStream_v3_0.cfs")]
    public void WriteToReadOnlyStreamThrows(string fileName)
    {
        using var rootStorage = RootStorage.OpenRead(fileName);
        using CfbStream stream = rootStorage.OpenStream("TestStream");
        Assert.ThrowsExactly<NotSupportedException>(() => stream.WriteByte(0));
        Assert.ThrowsExactly<NotSupportedException>(() => stream.Write([], 0, 0));
#if !NETSTANDARD2_0 && !NETFRAMEWORK
        Assert.ThrowsExactly<NotSupportedException>(() => stream.Write([]));
#endif
    }

    [TestMethod]
    [DataRow(Version.V3, 0, 100)] // Empty stream and root start with EndOfChain
    [DataRow(Version.V3, 0, 5000)]
    [DataRow(Version.V3, 4096, 100)] // Root starts with EndOfChain
    [DataRow(Version.V4, 0, 100)]
    [DataRow(Version.V4, 0, 5000)]
    [DataRow(Version.V4, 4096, 100)]
    public void WriteToFileWithEndOfChainStartSectors(Version version, int existingLength, int length)
    {
        // Files written by the reference implementation start empty chains with EndOfChain instead of NoStream
        byte[] data = TestData.CreateByteArray(length);
        using MemoryStream memoryStream = TestData.CreateMemoryStreamFromFile($"TestStream_v{(int)version}_{existingLength}.cfs");
        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen))
        {
            using (CfbStream stream = rootStorage.OpenStream("TestStream"))
            {
                stream.Seek(0, SeekOrigin.End);
                stream.Write(data, 0, data.Length);
            }

            using (CfbStream stream = rootStorage.CreateStream("Added"))
                stream.Write(data, 0, data.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());

            byte[] expected = [.. TestData.CreateByteArray(existingLength), .. data];
            using (CfbStream stream = rootStorage.OpenStream("TestStream"))
            {
                byte[] actual = new byte[expected.Length];
                Assert.AreEqual(expected.Length, stream.Length);
                stream.ReadExactly(actual);
                CollectionAssert.AreEqual(expected, actual);
            }

            using (CfbStream stream = rootStorage.OpenStream("Added"))
            {
                byte[] actual = new byte[data.Length];
                stream.ReadExactly(actual);
                CollectionAssert.AreEqual(data, actual);
            }
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void ReadViaCopyTo(Version version, int length)
    {
        // Test files are filled with bytes equal to their position modulo 256
        using MemoryStream expectedStream = new(length);
        for (int i = 0; i < length; i++)
            expectedStream.WriteByte((byte)i);

        string fileName = $"TestStream_v{(int)version}_{length}.cfs";
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);

        using Stream stream = rootStorage.OpenStream("TestStream");
        Assert.AreEqual(length, stream.Length);

        using MemoryStream actualStream = new();
        stream.CopyTo(actualStream);

        StreamAssert.AreEqual(expectedStream, actualStream);
    }

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void ReadFromStreamWithShortReads(Version version, int length)
    {
        // Test files are filled with bytes equal to their position modulo 256
        byte[] expected = TestData.CreateByteArray(length);

        string fileName = $"TestStream_v{(int)version}_{length}.cfs";
        using ShortReadMemoryStream baseStream = new(File.ReadAllBytes(fileName));
        using var rootStorage = RootStorage.Open(baseStream, StorageModeFlags.StrictValidation);
        using CfbStream stream = rootStorage.OpenStream("TestStream");

        byte[] actual = new byte[length];
        stream.ReadExactly(actual, 0, actual.Length);
        CollectionAssert.AreEqual(expected, actual);

#if !NETFRAMEWORK
        actual.AsSpan().Clear();
        stream.Position = 0;
        stream.ReadExactly(actual.AsSpan());
        CollectionAssert.AreEqual(expected, actual);
#endif
    }

#if !NETSTANDARD2_0 && !NETFRAMEWORK
    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void ReadSpan(Version version, int length)
    {
        // Test files are filled with bytes equal to their position modulo 256
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        string fileName = $"TestStream_v{(int)version}_{length}.cfs";
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);

        using Stream stream = rootStorage.OpenStream("TestStream");
        Assert.AreEqual(length, stream.Length);

        byte[] actualBuffer = new byte[length];
        stream.ReadExactly(actualBuffer);

        CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
    }
#endif

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void ReadSingleByte(Version version, int length)
    {
        string fileName = $"TestStream_v{(int)version}_{length}.cfs";
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        using Stream stream = rootStorage.OpenStream("TestStream");
        Assert.AreEqual(length, stream.Length);

        // Test files are filled with bytes equal to their position modulo 256
        using MemoryStream expectedStream = new(length);
        for (int i = 0; i < length; i++)
            expectedStream.WriteByte((byte)i);

        using MemoryStream actualStream = new();
        for (int i = 0; i < length; i++)
        {
            int value = stream.ReadByte();
            Assert.AreNotEqual(-1, value, "End of stream");
            actualStream.WriteByte((byte)value);
        }

        StreamAssert.AreEqual(expectedStream, actualStream);
    }

    [TestMethod]
    [DataRow(Version.V3, 64)] // Mini-stream
    [DataRow(Version.V4, 4096)] // Regular stream
    public void Seek(Version version, int length)
    {
        string fileName = $"TestStream_v{(int)version}_{length}.cfs";
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        using Stream stream = rootStorage.OpenStream("TestStream");

        Assert.AreEqual(0, stream.Seek(0, SeekOrigin.Begin));
        Assert.AreEqual(0, stream.Seek(0, SeekOrigin.Current));
        Assert.AreEqual(length, stream.Seek(0, SeekOrigin.End));

        stream.Position = 0;

        Assert.ThrowsExactly<IOException>(() => stream.Seek(-1, SeekOrigin.Begin));
        Assert.ThrowsExactly<IOException>(() => stream.Seek(-1, SeekOrigin.Current));
        Assert.ThrowsExactly<IOException>(() => stream.Seek(-1 - length, SeekOrigin.End));

        Assert.ThrowsExactly<ArgumentException>(() => stream.Seek(length, (SeekOrigin)3));
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void WriteArray(Version version, int length) => WriteCore(version, length, WriteMode.Array);

#if !NETSTANDARD2_0 && !NETFRAMEWORK
    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void WriteSpan(Version version, int length) => WriteCore(version, length, WriteMode.Span);

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void WriteSingleByte(Version version, int length) => WriteCore(version, length, WriteMode.SingleByte);

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void WriteSpanGrowthWithinMiniSectorPersistsStreamLength(Version version)
    {
        const int initialLength = 65;
        const byte appendedByte = 0xA5;

        byte[] expectedBuffer = new byte[initialLength + 1];
        TestData.CreateByteArray(initialLength).CopyTo(expectedBuffer, 0);
        expectedBuffer[^1] = appendedByte;

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream");
            stream.Write(expectedBuffer, 0, initialLength);
            stream.Flush();

            stream.Position = initialLength;
            byte[] appendedBuffer = [appendedByte];
            stream.Write(appendedBuffer.AsSpan());
            Assert.AreEqual(expectedBuffer.Length, stream.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.OpenStream("TestStream");
            Assert.AreEqual(expectedBuffer.Length, stream.Length);

            byte[] actualBuffer = new byte[expectedBuffer.Length];
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
    }
#endif

    static void WriteCore(Version version, int length, WriteMode mode)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("TestStream");
        Assert.AreEqual(0, stream.Length);

        byte[] expectedBuffer = TestData.CreateByteArray(length);
        stream.Write(expectedBuffer, mode);
        Assert.AreEqual(length, stream.Length);
        Assert.AreEqual(length, stream.Position);

        rootStorage.Validate();

        byte[] actualBuffer = new byte[length];
        stream.Position = 0;
        stream.ReadExactly(actualBuffer);

        CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void WriteThenRead(Version version, int length)
    {
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        byte[] actualBuffer = new byte[length];
        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.OpenStream("TestStream");
            rootStorage.Validate();
            Assert.AreEqual(length, stream.Length);

            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }

#if WINDOWS
        using (var rootStorage = StructuredStorage.Storage.Open(memoryStream))
        {
            IEnumerable<string> entries = rootStorage.EnumerateEntries();
            using StructuredStorage.Stream stream = rootStorage.OpenStream("TestStream");
            Assert.AreEqual(length, stream.Length);

            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
#endif
    }

#if WINDOWS
    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void StructuredStorageWriteThenRead(Version version, int length)
    {
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        string fileName = Path.GetTempFileName();
        File.Delete(fileName);

        using (var rootStorage = StructuredStorage.Storage.Create(fileName, StructuredStorage.StorageModes.AccessReadWrite | StructuredStorage.StorageModes.ShareExclusive, version == Version.V4))
        {
            IEnumerable<string> entries = rootStorage.EnumerateEntries();
            using StructuredStorage.Stream stream = rootStorage.CreateStream("TestStream");

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
            Assert.AreEqual(length, stream.Length);
        }

        byte[] actualBuffer = new byte[length];
        using (var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.OpenStream("TestStream");
            rootStorage.Validate();
            Assert.AreEqual(length, stream.Length);

            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }

        TestFile.TryDelete(fileName);
    }
#endif

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void WriteMultiple(Version version, int length)
    {
        const int IterationCount = 2048;
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("TestStream");
        Assert.AreEqual(0, stream.Length);

        byte[] expectedBuffer = TestData.CreateByteArray(length);

        for (int i = 0; i < IterationCount; i++)
        {
            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
            Assert.AreEqual(length * (i + 1), stream.Length);
        }

        stream.Flush();

        byte[] actualBuffer = new byte[length];
        stream.Position = 0;
        for (int i = 0; i < IterationCount; i++)
        {
            actualBuffer.AsSpan().Clear();
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
    }

    [TestMethod]
    [DataRow(Version.V3, 32)]
    [DataRow(Version.V4, 256)]
    public void CreateMultipleStreams(Version version, int streamCount)
    {
        using var rootStorage = RootStorage.CreateInMemory(version);
        for (int i = 0; i < streamCount; i++)
        {
            Assert.HasCount(i, rootStorage.EnumerateEntries());

            string streamName = $"TestStream{i}";
            using Stream stream = rootStorage.CreateStream(streamName);
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void Modify(Version version, int length)
    {
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream1");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream2");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            rootStorage.Validate();

            using (CfbStream stream = rootStorage.OpenStream("TestStream1"))
            {
                Assert.AreEqual(length, stream.Length);

                byte[] actualBuffer = new byte[length];
                stream.ReadExactly(actualBuffer);
                CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
            }

            using (CfbStream stream = rootStorage.OpenStream("TestStream2"))
            {
                Assert.AreEqual(length, stream.Length);

                byte[] actualBuffer = new byte[length];
                stream.ReadExactly(actualBuffer);
                CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
            }
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void ModifyCommitArray(Version version, int length) => ModifyCommit(version, length, WriteMode.Array);

#if !NETSTANDARD2_0 && !NETFRAMEWORK
    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void ModifyCommitSpan(Version version, int length) => ModifyCommit(version, length, WriteMode.Span);
#endif

#if !NETSTANDARD2_0 && !NETFRAMEWORK
    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void ModifyCommitSingleByte(Version version, int length) => ModifyCommit(version, length, WriteMode.SingleByte);
#endif

    static void ModifyCommit(Version version, int length, WriteMode writeMode)
    {
        // Fill with bytes equal to their position modulo 256
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream1");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.Transacted | StorageModeFlags.StrictValidation))
        {
            using (CfbStream stream = rootStorage.CreateStream("TestStream2"))
            {
                Assert.AreEqual(0, stream.Length);

                stream.Write(expectedBuffer, writeMode);
            }

            rootStorage.Commit();
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            rootStorage.Validate();

            using (CfbStream stream = rootStorage.OpenStream("TestStream1"))
            {
                Assert.AreEqual(length, stream.Length);

                byte[] actualBuffer = new byte[length];
                stream.ReadExactly(actualBuffer);
                CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
            }

            using (CfbStream stream = rootStorage.OpenStream("TestStream2"))
            {
                Assert.AreEqual(length, stream.Length);

                byte[] actualBuffer = new byte[length];
                stream.ReadExactly(actualBuffer);
                CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
            }
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void TransactedRead(Version version, int length)
    {
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream1");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.Transacted | StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.OpenStream("TestStream1");
            byte[] actualBuffer = new byte[length];
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
    }

    [TestMethod]
    [DataRow(Version.V3, (int)WriteMode.Array)]
    [DataRow(Version.V4, (int)WriteMode.Array)]
#if !NETSTANDARD2_0 && !NETFRAMEWORK
    [DataRow(Version.V3, (int)WriteMode.Span)]
    [DataRow(Version.V4, (int)WriteMode.Span)]
#endif
    public void TransactedWriteAcrossSectorBoundary(Version version, int writeModeValue)
    {
        var writeMode = (WriteMode)writeModeValue;
        int sectorSize = version == Version.V3 ? 512 : 4096;
        int streamLength = sectorSize * 2;

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream1");
            stream.SetLength(streamLength);
        }

        byte[] expectedBuffer = new byte[streamLength];
        byte[] writeBuffer = TestData.CreateByteArray(32);
        int writeOffset = sectorSize - 8;
        Array.Copy(writeBuffer, 0, expectedBuffer, writeOffset, writeBuffer.Length);

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.Transacted | StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.OpenStream("TestStream1");
            stream.Position = writeOffset;
            stream.Write(writeBuffer, writeMode);
            rootStorage.Commit();
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        using (CfbStream stream = rootStorage.OpenStream("TestStream1"))
        {
            byte[] actualBuffer = new byte[streamLength];
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void ModifyRevert(Version version, int length)
    {
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream1");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.Transacted | StorageModeFlags.StrictValidation))
        {
            using CfbStream stream = rootStorage.CreateStream("TestStream2");
            Assert.AreEqual(0, stream.Length);

            stream.Write(expectedBuffer, 0, expectedBuffer.Length);
            rootStorage.Revert();
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            rootStorage.Validate();

            using (CfbStream stream = rootStorage.OpenStream("TestStream1"))
            {
                Assert.AreEqual(length, stream.Length);

                byte[] actualBuffer = new byte[length];
                stream.ReadExactly(actualBuffer);
                CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
            }

            Assert.ThrowsExactly<FileNotFoundException>(() => rootStorage.OpenStream("TestStream2"));
        }
    }

    [TestMethod]
    [DynamicData(nameof(TestData.VersionsAndSizes), typeof(TestData))]
    public void Shrink(Version version, int length)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("Test");

        byte[] expectedBuffer = TestData.CreateByteArray(length);
        stream.Write(expectedBuffer, 0, expectedBuffer.Length);
        Assert.AreEqual(length, stream.Length);

        long baseStreamLength = memoryStream.Length;

        int newLength = length / 2;
        stream.SetLength(newLength);
        Assert.AreEqual(newLength, stream.Length);

        stream.Position = newLength;
        stream.Write(expectedBuffer, newLength, expectedBuffer.Length - newLength);
        Assert.AreEqual(length, stream.Length);

        byte[] actualBuffer = new byte[length];
        stream.Seek(0, SeekOrigin.Begin);
        stream.ReadExactly(actualBuffer);

        CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void MiniFatToFat(Version version)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("Test");

        int length = 256;
        byte[] expectedBuffer = TestData.CreateByteArray(length);

        int iterations = (int)Header.MiniStreamCutoffSize / length;
        for (int i = 0; i < iterations; i++)
            stream.Write(expectedBuffer, 0, expectedBuffer.Length);

        Assert.AreEqual(length * iterations, stream.Length);

        byte[] actualBuffer = new byte[length];
        stream.Position = 0;
        for (int i = 0; i < iterations; i++)
        {
            actualBuffer.AsSpan().Clear();
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void FatToMiniFat(Version version)
    {
        const int length = 256;

        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("Test");

        byte[] expectedBuffer = TestData.CreateByteArray(length);
        int iterations = (int)Header.MiniStreamCutoffSize / length;
        for (int i = 0; i < iterations; i++)
            stream.Write(expectedBuffer, 0, expectedBuffer.Length);

        Assert.AreEqual(length * iterations, stream.Length);

        byte[] actualBuffer = new byte[length];

        // Check reading from the regular sectors
        stream.Position = 0;
        for (int i = 0; i < iterations; i++)
        {
            actualBuffer.AsSpan().Clear();
            stream.ReadExactly(actualBuffer);
            CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
        }

        stream.SetLength(length);
        Assert.AreEqual(length, stream.Length);

        stream.Position = 0;
        stream.ReadExactly(actualBuffer);
        CollectionAssert.AreEqual(expectedBuffer, actualBuffer);
    }

    [TestMethod]
    [DynamicData(nameof(TestData.ShortVersionsAndSizes), typeof(TestData))]
    public void CopyFromStream(Version version, int length)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("TestStream");
        Assert.AreEqual(0, stream.Length);

        // Fill with bytes equal to their position modulo 256
        using MemoryStream expectedStream = new(length);
        for (int i = 0; i < length; i++)
            expectedStream.WriteByte((byte)i);

        expectedStream.Position = 0;
        expectedStream.CopyTo(stream);
        Assert.AreEqual(length, stream.Length);

        using MemoryStream actualStream = new();
        stream.Seek(0, SeekOrigin.Begin);
        stream.CopyTo(actualStream);

        StreamAssert.AreEqual(expectedStream, actualStream);
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void CreateDuplicateStreamThrowsException(Version version)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        using CfbStream stream = rootStorage.CreateStream("Test");
        Assert.ThrowsExactly<IOException>(() => rootStorage.CreateStream("Test"));
    }

    [TestMethod]
    [DataRow(Version.V3, RootContext.MaximumV3StreamLength)]
    [DataRow(Version.V4, SectorType.Maximum * 4096L)]
    public void MaximumLength(Version version, long length)
    {
        using var rootStorage = RootStorage.CreateInMemory(version);
        using CfbStream stream = rootStorage.CreateStream("Test");
        ArgumentOutOfRangeException setLengthException = Assert.ThrowsExactly<ArgumentOutOfRangeException>(() => stream.SetLength(length + 1));
        ArgumentOutOfRangeException setPositionException = Assert.ThrowsExactly<ArgumentOutOfRangeException>(() => stream.Position = length + 1);
        Assert.AreEqual("value", setLengthException.ParamName);
        Assert.AreEqual("offset", setPositionException.ParamName);

        stream.Position = length;
        Assert.Throws<IOException>(() => stream.WriteByte(0));
    }

    [TestMethod]
    [DataRow(Version.V3, 1024)]
    [DataRow(Version.V3, 16 * 1024)]
    [DataRow(Version.V4, 1024)]
    [DataRow(Version.V4, 16 * 1024)]
    public void FlushAfterAddingSiblingKeepsSibling(Version version, int length)
    {
        byte[] data = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            using CfbStream stream = rootStorage.CreateStream("B");
            stream.Write(data, 0, data.Length);

            // Adding "C" links it as the right sibling of "B" while the open stream holds an older copy of its entry
            rootStorage.CreateStream("C");
            stream.Write(data, 0, data.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            Assert.IsTrue(rootStorage.ContainsEntry("C"));
            using CfbStream stream = rootStorage.OpenStream("B");
            Assert.AreEqual(2L * length, stream.Length);
        }
    }

    [TestMethod]
    [DataRow(Version.V3, 1024)]
    [DataRow(Version.V3, 16 * 1024)]
    [DataRow(Version.V4, 1024)]
    [DataRow(Version.V4, 16 * 1024)]
    public void FlushAfterDeletingSiblingDoesNotRestoreSibling(Version version, int length)
    {
        byte[] data = TestData.CreateByteArray(length);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            rootStorage.CreateStream("B");
            rootStorage.CreateStream("C");

            using CfbStream stream = rootStorage.OpenStream("B");
            stream.Write(data, 0, data.Length);

            rootStorage.Delete("C");
            stream.Write(data, 0, data.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            Assert.IsFalse(rootStorage.ContainsEntry("C"));
            Assert.HasCount(1, rootStorage.EnumerateEntries());
        }
    }

    // Reads fewer bytes than requested, which the Stream contract allows
    sealed class ShortReadMemoryStream : MemoryStream
    {
        const int MaxReadLength = 7;

        public ShortReadMemoryStream(byte[] buffer)
            : base(buffer, writable: false)
        {
        }

        public override int Read(byte[] buffer, int offset, int count) => base.Read(buffer, offset, Math.Min(count, MaxReadLength));

#if !NETFRAMEWORK
        public override int Read(Span<byte> buffer) => base.Read(buffer[..Math.Min(buffer.Length, MaxReadLength)]);
#endif
    }
}
