﻿namespace OpenMcdf.Tests;

[TestClass]
public sealed class StorageTests
{
    [TestMethod]
    [DataRow("MultipleStorage.cfs", 1)]
    [DataRow("MultipleStorage2.cfs", 1)]
    [DataRow("MultipleStorage3.cfs", 1)]
    [DataRow("MultipleStorage4.cfs", 1)]
    public void EnumerateEntries(string fileName, long storageCount)
    {
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        IEnumerable<EntryInfo> storageEntries = rootStorage.EnumerateEntries();
        Assert.AreEqual(storageCount, storageEntries.Count());
    }

    [TestMethod]
    [DataRow("MultipleStorage.cfs")]
    public void OpenStorage(string fileName)
    {
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        Assert.IsTrue(rootStorage.TryOpenStorage("MyStorage", out Storage? _));
        Assert.IsFalse(rootStorage.TryOpenStorage(string.Empty, out Storage? _));

        Assert.ThrowsExactly<DirectoryNotFoundException>(() => rootStorage.OpenStorage(string.Empty));

        Assert.IsTrue(rootStorage.ContainsEntry("MyStorage"));
        Assert.IsFalse(rootStorage.ContainsEntry("NonExistentStorage"));

        bool found = rootStorage.TryGetEntryInfo("MyStorage", out EntryInfo entryInfo);
        Assert.IsTrue(found);
        Assert.AreEqual("MyStorage", entryInfo.Name);

        Storage storage = rootStorage.OpenStorage("MyStorage");
        Assert.AreEqual("MyStorage", storage.EntryInfo.Name);
    }

    [TestMethod]
    [DataRow("FatChainLoop_v3.cfs")]
    [Ignore("Test file has multiple validation errors")]
    public void FatChainLoop(string fileName)
    {
        using var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation);
        Assert.ThrowsExactly<FileFormatException>(() => rootStorage.OpenStorage("Anything"));
    }

    [TestMethod]
    [DataRow(Version.V3, 0)]
    [DataRow(Version.V3, 1)]
    [DataRow(Version.V3, 2)]
    [DataRow(Version.V3, 4)] // Required 2 sectors including root
    [DataRow(Version.V4, 0)]
    [DataRow(Version.V4, 1)]
    [DataRow(Version.V4, 2)]
    [DataRow(Version.V4, 32)] // Required 2 sectors including root
    public void CreateStorage(Version version, int subStorageCount)
    {
        using MemoryStream memoryStream = new();

        // Test adding right sibling
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            for (int i = 0; i < subStorageCount; i++)
                rootStorage.CreateStorage($"Test{i}");
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.StrictValidation))
        {
            IEnumerable<EntryInfo> entries = rootStorage.EnumerateEntries();
            Assert.HasCount(subStorageCount, entries);

            for (int i = 0; i < subStorageCount; i++)
                rootStorage.OpenStorage($"Test{i}");
        }

        // Test adding left sibling
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            for (int i = 0; i < subStorageCount; i++)
                rootStorage.CreateStorage($"Test{subStorageCount - i}");
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.StrictValidation))
        {
            IEnumerable<EntryInfo> entries = rootStorage.EnumerateEntries();
            Assert.HasCount(subStorageCount, entries);

            for (int i = 0; i < subStorageCount; i++)
                rootStorage.OpenStorage($"Test{subStorageCount - i}");
        }

#if WINDOWS
        using (var rootStorage = StructuredStorage.Storage.Open(memoryStream))
        {
            IEnumerable<string> entries = rootStorage.EnumerateEntries();
            Assert.HasCount(subStorageCount, entries);

            for (int i = 0; i < subStorageCount; i++)
            {
                using StructuredStorage.Storage storage = rootStorage.OpenStorage($"Test{subStorageCount - i}");
            }
        }
#endif
    }

    [TestMethod]
    public void CreateInvalidStorageName()
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream);
        Assert.ThrowsExactly<ArgumentException>(() => rootStorage.CreateStorage("!"));
        Assert.ThrowsExactly<ArgumentException>(() => rootStorage.CreateStorage("/"));
        Assert.ThrowsExactly<ArgumentException>(() => rootStorage.CreateStorage(":"));
        Assert.ThrowsExactly<ArgumentException>(() => rootStorage.CreateStorage("\\"));
    }

    [TestMethod]
    [DataRow(Version.V3, 0)]
    [DataRow(Version.V3, 1)]
    [DataRow(Version.V4, 0)]
    [DataRow(Version.V4, 1)]
    public void CreateStorageFile(Version version, int subStorageCount)
    {
        string fileName = Path.GetTempFileName();

        try
        {
            using (var rootStorage = RootStorage.Create(fileName, version))
            {
                for (int i = 0; i < subStorageCount; i++)
                    rootStorage.CreateStorage($"Test{i}");
            }

            using (var rootStorage = RootStorage.OpenRead(fileName, StorageModeFlags.StrictValidation))
            {
                IEnumerable<EntryInfo> entries = rootStorage.EnumerateEntries();
                Assert.HasCount(subStorageCount, entries);

                for (int i = 0; i < subStorageCount; i++)
                    rootStorage.OpenStorage($"Test{i}");
            }
        }
        finally
        {
            TestFile.TryDelete(fileName);
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void CreateDuplicateStorageThrowsException(Version version)
    {
        using MemoryStream memoryStream = new();
        using var rootStorage = RootStorage.Create(memoryStream, version);
        rootStorage.CreateStorage("Test");
        Assert.ThrowsExactly<IOException>(() => rootStorage.CreateStorage("Test"));
    }

    private static MemoryStream CreateDeleteTest(Version version, int count)
    {
        MemoryStream stream = new();
        using var rootStorage = RootStorage.Create(stream, version, StorageModeFlags.LeaveOpen);

        int mid = (count + 1) / 2;
        rootStorage.CreateStorage($"{mid}");
        for (int i = 0; i < count - 1; i++)
        {
            int name;
            if (i % 2 == 0)
                name = mid - i / 2 - 1;
            else
                name = mid + i / 2 + 1;
            rootStorage.CreateStorage($"{name}");
        }

        return stream;
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStorageLeaves(Version version)
    {
        using MemoryStream memoryStream = CreateDeleteTest(version, 3);
        using var rootStorage = RootStorage.Open(memoryStream);

        rootStorage.Delete("NonExistentEntry");
        Assert.HasCount(3, rootStorage.EnumerateEntries());

        // Left
        rootStorage.Delete("1");
        Assert.HasCount(2, rootStorage.EnumerateEntries());

        // Right
        rootStorage.Delete("3");
        Assert.HasCount(1, rootStorage.EnumerateEntries());

        // Root
        rootStorage.Delete("2");
        Assert.IsEmpty(rootStorage.EnumerateEntries());
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStorageRoot(Version version)
    {
        using MemoryStream memoryStream = CreateDeleteTest(version, 3);
        using var rootStorage = RootStorage.Open(memoryStream);

        rootStorage.Delete("2");
        Assert.HasCount(2, rootStorage.EnumerateEntries());

        rootStorage.Delete("1");
        Assert.HasCount(1, rootStorage.EnumerateEntries());

        rootStorage.Delete("3");
        Assert.IsEmpty(rootStorage.EnumerateEntries());
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStorageBranch(Version version)
    {
        const int count = 15;

        for (int i = 0; i < count; i++)
        {
            using MemoryStream memoryStream = CreateDeleteTest(version, count);
            using var rootStorage = RootStorage.Open(memoryStream);

            for (int j = 0; j < count; j++)
            {
                int name = (i + j) % count + 1;
                rootStorage.Delete($"{name}");
                Assert.HasCount(count - 1 - j, rootStorage.EnumerateEntries());
            }
        }
    }

#if WINDOWS
    private static string CreateBalancedDeleteTest(int count)
    {
        string fileName = $"BalancedDelete_{count}.cfs";
        File.Delete(fileName);
        using var rootStorage = StructuredStorage.Storage.Create(fileName);
        for (int i = 0; i < count; i++)
        {
            using StructuredStorage.Storage storage = rootStorage.CreateStorage($"{i + 1}");
        }

        return fileName;
    }

    [TestMethod]
    public void DeleteBalancedStorageBranch()
    {
        const int count = 31;

        for (int i = 0; i < count; i++)
        {
            string fileName = CreateBalancedDeleteTest(count);
            using var rootStorage = RootStorage.Open(fileName, FileMode.Open);

            for (int j = 0; j < count; j++)
            {
                int name = (i + j) % count + 1;
                rootStorage.Delete($"{name}");
                Assert.HasCount(count - 1 - j, rootStorage.EnumerateEntries());
            }
        }
    }
#endif

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStorageRecursively(Version version)
    {
        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            Storage storage = rootStorage.CreateStorage("Storage");
            Assert.HasCount(1, rootStorage.EnumerateEntries());

            Storage subStorage = storage.CreateStorage("SubStorage");
            using CfbStream subStream = subStorage.CreateStream("SubStream");
            Assert.HasCount(1, storage.EnumerateEntries());
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.LeaveOpen | StorageModeFlags.StrictValidation))
        {
            rootStorage.Delete("Storage");
            Assert.IsEmpty(rootStorage.EnumerateEntries());
            rootStorage.Validate();
        }

        using (var rootStorage = RootStorage.Open(memoryStream))
        {
            Assert.IsEmpty(rootStorage.EnumerateEntries());
            rootStorage.Validate();
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStorageWithStreamChildReusesFreedSectors(Version version)
    {
        using MemoryStream memoryStream = new();
        byte[] data = TestData.CreateByteArray(16 * 1024);

        using var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen);
        Storage storage = rootStorage.CreateStorage("Storage");
        using (CfbStream subStream = storage.CreateStream("SubStream"))
        {
            subStream.Write(data, 0, data.Length);
        }

        rootStorage.Flush();
        long initialLength = rootStorage.BaseStream.Length;

        rootStorage.Delete("Storage");
        rootStorage.Flush();

        using (CfbStream replacement = rootStorage.CreateStream("Replacement"))
        {
            replacement.Write(data, 0, data.Length);
        }

        rootStorage.Flush();

        Assert.AreEqual(initialLength, rootStorage.BaseStream.Length);
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteStream(Version version)
    {
        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            rootStorage.CreateStream("Test");
            Assert.HasCount(1, rootStorage.EnumerateEntries());
        }

        using (var rootStorage = RootStorage.Open(memoryStream))
        {
            rootStorage.Delete("Test");
            Assert.IsEmpty(rootStorage.EnumerateEntries());
        }
    }

    [TestMethod]
    [DataRow(Version.V3, 100)]
    [DataRow(Version.V3, 5000)]
    [DataRow(Version.V4, 100)]
    [DataRow(Version.V4, 5000)]
    public void DeleteInvalidatesOpenObjects(Version version, int length)
    {
        byte[] data = TestData.CreateByteArray(length);
        byte[] otherData = new byte[length * 2];
        otherData.AsSpan().Fill(7);

        using MemoryStream memoryStream = new();
        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            CfbStream deletedStream = rootStorage.CreateStream("DeletedStream");
            deletedStream.Write(data, 0, data.Length);
            Storage deletedStorage = rootStorage.CreateStorage("DeletedStorage");
            CfbStream deletedChild = deletedStorage.CreateStream("Child");
            deletedChild.Write(data, 0, data.Length);
            using CfbStream sibling = rootStorage.CreateStream("Sibling");

            // Flush so deleting frees the allocated sectors, then leave directory updates pending without changing
            // the data, so disposal would write stale entries
            foreach (CfbStream stream in new[] { deletedStream, deletedChild })
            {
                stream.Flush();
                stream.SetLength(stream.Length);
            }

            rootStorage.Delete("DeletedStream");
            rootStorage.Delete("DeletedStorage");

            // New entries recycle the deleted entries and sectors
            using (CfbStream stream = rootStorage.CreateStream("Added1"))
                stream.Write(otherData, 0, otherData.Length);
            using (CfbStream stream = rootStorage.CreateStream("Added2"))
                stream.Write(otherData, 0, otherData.Length);
            rootStorage.CreateStorage("Added3");

            foreach (CfbStream stream in new[] { deletedStream, deletedChild })
            {
                Assert.IsFalse(stream.CanWrite);
                Assert.ThrowsExactly<InvalidOperationException>(() => stream.Write(data, 0, data.Length));
                Assert.ThrowsExactly<InvalidOperationException>(() => stream.SetLength(0));
                Assert.ThrowsExactly<InvalidOperationException>(() => stream.Length);
            }

            Assert.ThrowsExactly<InvalidOperationException>(() => deletedStorage.EntryInfo);
            Assert.ThrowsExactly<InvalidOperationException>(() => deletedStorage.CreateStream("Other"));

            // Disposing the deleted streams must not write to the recycled entries
            deletedStream.Dispose();
            deletedChild.Dispose();

            // Objects for other entries remain valid
            sibling.Write(data, 0, data.Length);
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            CollectionAssert.AreEquivalent(new[] { "Sibling", "Added1", "Added2", "Added3" }, rootStorage.EnumerateEntries().Select(e => e.Name).ToList());

            foreach (string name in new[] { "Added1", "Added2" })
            {
                using CfbStream stream = rootStorage.OpenStream(name);
                byte[] actual = new byte[otherData.Length];
                Assert.AreEqual(otherData.Length, stream.Length);
                stream.ReadExactly(actual);
                CollectionAssert.AreEqual(otherData, actual);
            }
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void DeleteInvalidatesStartedEnumeration(Version version)
    {
        using var rootStorage = RootStorage.CreateInMemory(version);
        Storage storage = rootStorage.CreateStorage("Storage");
        storage.CreateStorage("Child1");
        storage.CreateStorage("Child2");

        using IEnumerator<EntryInfo> entries = storage.EnumerateEntries().GetEnumerator();
        Assert.IsTrue(entries.MoveNext());

        rootStorage.Delete("Storage");

        Assert.ThrowsExactly<InvalidOperationException>(() => entries.MoveNext());
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void GetAndSetMetadata(Version version)
    {
        using MemoryStream memoryStream = new();

        var guid = Guid.NewGuid();
        DateTime now = DateTime.UtcNow;

        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            Storage storage = rootStorage.CreateStorage("Storage");

            Assert.AreEqual(Guid.Empty, storage.CLSID);
            Assert.AreNotEqual(FileTime.UtcZero, storage.CreationTime);
            Assert.AreNotEqual(FileTime.UtcZero, storage.ModifiedTime);
            Assert.AreEqual(0U, storage.StateBits);

            storage.CLSID = guid;
            storage.CreationTime = now;
            storage.ModifiedTime = now;
            storage.StateBits = 1U;
        }

        using (var rootStorage = RootStorage.Open(memoryStream))
        {
            Storage storage = rootStorage.OpenStorage("Storage");

            Assert.AreEqual(guid, storage.CLSID);
            Assert.AreEqual(now, storage.CreationTime);
            Assert.AreEqual(now, storage.ModifiedTime);
            Assert.AreEqual(1U, storage.StateBits);
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void SetMetadataAfterAddingSiblingKeepsSibling(Version version)
    {
        using MemoryStream memoryStream = new();
        var guid = Guid.NewGuid();

        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            Storage storage = rootStorage.CreateStorage("B");

            // Adding "C" links it as the right sibling of "B" while the open storage holds an older copy of its entry
            rootStorage.CreateStorage("C");
            storage.CLSID = guid;
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            Assert.IsTrue(rootStorage.ContainsEntry("C"));
            Assert.AreEqual(guid, rootStorage.OpenStorage("B").CLSID);
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void AddFirstChildAfterAddingSiblingKeepsSibling(Version version)
    {
        using MemoryStream memoryStream = new();

        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            Storage storage = rootStorage.CreateStorage("B");
            rootStorage.CreateStorage("C");

            // Adding the first child writes the child ID of "B"
            storage.CreateStorage("Child");
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            Assert.IsTrue(rootStorage.ContainsEntry("C"));
            Assert.IsTrue(rootStorage.OpenStorage("B").ContainsEntry("Child"));
        }
    }

    [TestMethod]
    [DataRow(Version.V3)]
    [DataRow(Version.V4)]
    public void ChildrenAreSharedBetweenOpenStorages(Version version)
    {
        using MemoryStream memoryStream = new();

        using (var rootStorage = RootStorage.Create(memoryStream, version, StorageModeFlags.LeaveOpen))
        {
            rootStorage.CreateStorage("Storage");
            Storage storage1 = rootStorage.OpenStorage("Storage");
            Storage storage2 = rootStorage.OpenStorage("Storage");

            storage1.CreateStream("A");
            Assert.IsTrue(storage2.ContainsEntry("A"));
            Assert.HasCount(1, storage2.EnumerateEntries());

            storage2.CreateStream("B");
            Assert.IsTrue(storage1.ContainsEntry("B"));

            storage2.Delete("A");
            Assert.IsFalse(storage1.ContainsEntry("A"));
        }

        using (var rootStorage = RootStorage.Open(memoryStream, StorageModeFlags.StrictValidation))
        {
            Assert.IsTrue(rootStorage.Validate());
            Storage storage = rootStorage.OpenStorage("Storage");
            Assert.IsFalse(storage.ContainsEntry("A"));
            Assert.IsTrue(storage.ContainsEntry("B"));
        }
    }
}
