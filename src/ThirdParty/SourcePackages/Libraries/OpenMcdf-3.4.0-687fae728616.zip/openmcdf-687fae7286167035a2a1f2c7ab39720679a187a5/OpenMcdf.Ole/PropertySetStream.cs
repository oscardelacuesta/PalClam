﻿namespace OpenMcdf.Ole;

internal sealed class PropertySetStream
{
    private sealed class OffsetContainer(int offsetPS, int propertyCount)
    {
        public int OffsetPS { get; } = offsetPS;

        public long[] PropertyIdentifierOffsets { get; } = new long[propertyCount];

        public long[] PropertyOffsets { get; } = new long[propertyCount];
    }

    public ushort ByteOrder { get; set; }

    public ushort Version { get; set; }

    public uint SystemIdentifier { get; set; }

    public Guid CLSID { get; set; }

    public uint NumPropertySets { get; set; }

    public Guid FMTID0 { get; set; }

    public uint Offset0 { get; set; }

    public Guid FMTID1 { get; set; }

    public uint Offset1 { get; set; }

    public PropertySet? PropertySet0 { get; set; }

    public PropertySet? PropertySet1 { get; set; }

    public PropertySetStream()
    {
    }

    public void Read(BinaryReader br)
    {
        br.BaseStream.Position = 0;

        ByteOrder = br.ReadUInt16();
        Version = br.ReadUInt16();
        SystemIdentifier = br.ReadUInt32();
        CLSID = new Guid(br.ReadBytes(16));
        NumPropertySets = br.ReadUInt32();
        FMTID0 = new Guid(br.ReadBytes(16));
        Offset0 = br.ReadUInt32();

        if (NumPropertySets == 2)
        {
            FMTID1 = new Guid(br.ReadBytes(16));
            Offset1 = br.ReadUInt32();
        }

        uint size = br.ReadUInt32();
        uint propertyCount = br.ReadUInt32();
        PropertySet0 = new PropertySet
        {
            Size = size,
        };

        // Create appropriate property factory based on the stream type
        PropertyFactory factory = FMTID0 == FormatIdentifiers.DocSummaryInformation ? DocumentSummaryInfoPropertyFactory.Default : DefaultPropertyFactory.Default;

        // Read property offsets (P0)
        for (int i = 0; i < propertyCount; i++)
        {
            var pio = PropertyIdentifierAndOffset.Read(br);
            PropertySet0.PropertyIdentifierAndOffsets.Add(pio);
        }

        PropertySet0.LoadContext((int)Offset0, br);  // Read CodePage, Locale

        // Read properties (P0)
        for (int i = 0; i < propertyCount; i++)
        {
            PropertyIdentifierAndOffset propertyIdentifierAndOffset = PropertySet0.PropertyIdentifierAndOffsets[i];
            br.BaseStream.Seek(Offset0 + propertyIdentifierAndOffset.Offset, SeekOrigin.Begin);
            IProperty property = ReadProperty(propertyIdentifierAndOffset.PropertyIdentifier, PropertySet0.PropertyContext.CodePage, br, factory);
            PropertySet0.Properties.Add(property);
        }

        if (NumPropertySets == 2)
        {
            br.BaseStream.Seek(Offset1, SeekOrigin.Begin);

            size = br.ReadUInt32();
            propertyCount = br.ReadUInt32();

            PropertySet1 = new PropertySet
            {
                Size = size,
            };

            // Read property offsets
            for (int i = 0; i < propertyCount; i++)
            {
                var pio = PropertyIdentifierAndOffset.Read(br);
                PropertySet1.PropertyIdentifierAndOffsets.Add(pio);
            }

            PropertySet1.LoadContext((int)Offset1, br);

            // Read properties
            for (int i = 0; i < propertyCount; i++)
            {
                PropertyIdentifierAndOffset idAndOffset = PropertySet1.PropertyIdentifierAndOffsets[i];
                br.BaseStream.Seek(Offset1 + idAndOffset.Offset, SeekOrigin.Begin);
                IProperty property = ReadProperty(idAndOffset.PropertyIdentifier, PropertySet1.PropertyContext.CodePage, br, DefaultPropertyFactory.Default);
                PropertySet1.Properties.Add(property);
            }
        }
    }

    public void Write(BinaryWriter bw)
    {
        bw.BaseStream.Position = 0;

        bw.Write(ByteOrder);
        bw.Write(Version);
        bw.Write(SystemIdentifier);
        WriteGuid(bw, CLSID);
        bw.Write(NumPropertySets);
        WriteGuid(bw, FMTID0);
        bw.Write(Offset0);

        if (NumPropertySets == 2)
        {
            WriteGuid(bw, FMTID1);
            bw.Write(Offset1);
        }

        OffsetContainer oc0 = new((int)bw.BaseStream.Position, PropertySet0!.Properties.Count);
        OffsetContainer? oc1 = null;

        bw.Write(PropertySet0.Size);
        bw.Write(PropertySet0.Properties.Count);

        // w property offsets
        for (int i = 0; i < PropertySet0.Properties.Count; i++)
        {
            oc0.PropertyIdentifierOffsets[i] = bw.BaseStream.Position; // Offset of 4 to Offset value
            PropertySet0.PropertyIdentifierAndOffsets[i].Write(bw);
        }

        for (int i = 0; i < PropertySet0.Properties.Count; i++)
        {
            oc0.PropertyOffsets[i] = bw.BaseStream.Position;
            PropertySet0.Properties[i].Write(bw);
        }

        long padding0 = bw.BaseStream.Position % 4;

        if (padding0 > 0)
        {
            for (int p = 0; p < 4 - padding0; p++)
                bw.Write((byte)0);
        }

        int size0 = (int)(bw.BaseStream.Position - oc0.OffsetPS);

        if (NumPropertySets == 2)
        {
            oc1 = new((int)bw.BaseStream.Position, PropertySet1!.Properties.Count);

            bw.Write(PropertySet1.Size);
            bw.Write(PropertySet1.Properties.Count);

            // w property offsets
            for (int i = 0; i < PropertySet1.PropertyIdentifierAndOffsets.Count; i++)
            {
                oc1.PropertyIdentifierOffsets[i] = bw.BaseStream.Position; // Offset of 4 to Offset value
                PropertySet1.PropertyIdentifierAndOffsets[i].Write(bw);
            }

            for (int i = 0; i < PropertySet1.Properties.Count; i++)
            {
                oc1.PropertyOffsets[i] = bw.BaseStream.Position;
                PropertySet1.Properties[i].Write(bw);
            }

            int size1 = (int)(bw.BaseStream.Position - oc1.OffsetPS);

            bw.Seek(oc1.OffsetPS, SeekOrigin.Begin);
            bw.Write(size1);
        }

        bw.Seek(oc0.OffsetPS, SeekOrigin.Begin);
        bw.Write(size0);

        int shiftO1 = 2 + 2 + 4 + 16 + 4 + 16; // OFFSET0
        bw.Seek(shiftO1, SeekOrigin.Begin);
        bw.Write(oc0.OffsetPS);

        if (oc1 is not null)
        {
            bw.Seek(shiftO1 + 4 + 16, SeekOrigin.Begin);
            bw.Write(oc1.OffsetPS);
        }

        //-----------
        for (int i = 0; i < PropertySet0.PropertyIdentifierAndOffsets.Count; i++)
        {
            bw.Seek((int)oc0.PropertyIdentifierOffsets[i] + 4, SeekOrigin.Begin); // Offset of 4 to Offset value
            bw.Write((int)(oc0.PropertyOffsets[i] - oc0.OffsetPS));
        }

        if (oc1 is not null)
        {
            for (int i = 0; i < oc1.PropertyIdentifierOffsets.Length; i++)
            {
                bw.Seek((int)oc1.PropertyIdentifierOffsets[i] + 4, SeekOrigin.Begin); // Offset of 4 to Offset value
                bw.Write((int)(oc1.PropertyOffsets[i] - oc1.OffsetPS));
            }
        }
    }

    private static IProperty ReadProperty(uint propertyIdentifier, int codePage, BinaryReader br, PropertyFactory factory)
    {
        if (propertyIdentifier == SpecialPropertyIdentifiers.Dictionary)
        {
            return DictionaryProperty.Read(br, codePage);
        }

        var vType = (VTPropertyType)br.ReadUInt16();
        br.ReadUInt16(); // Ushort Padding

        return factory.ReadProperty(br, vType, codePage, propertyIdentifier);
    }

    private static void WriteGuid(BinaryWriter writer, in Guid value)
    {
#if NETSTANDARD2_0 || NETFRAMEWORK
        byte[] bytes = value.ToByteArray();
        writer.Write(bytes);
#else
        Span<byte> localBuffer = stackalloc byte[16];
        value.TryWriteBytes(localBuffer);
        writer.Write(localBuffer);
#endif
    }
}
