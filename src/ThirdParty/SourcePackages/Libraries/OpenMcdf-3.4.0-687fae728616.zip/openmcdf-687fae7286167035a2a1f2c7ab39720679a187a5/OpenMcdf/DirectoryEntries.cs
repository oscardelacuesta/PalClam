﻿using System.Diagnostics.CodeAnalysis;

namespace OpenMcdf;

internal enum SiblingType
{
    Left,
    Right,
}

/// <summary>
/// Encapsulates getting and adding <see cref="DirectoryEntry"/> objects.
/// </summary>
internal sealed class DirectoryEntries : ContextBase, IDisposable
{
    private readonly FatChainEnumerator fatChainEnumerator;
    private readonly DirectoryEntryEnumerator directoryEntryEnumerator;

    public DirectoryEntries(RootContextSite rootContextSite, bool create)
        : base(rootContextSite)
    {
        fatChainEnumerator = new FatChainEnumerator(ContextSite, Context.Header.FirstDirectorySectorId);
        directoryEntryEnumerator = new DirectoryEntryEnumerator(this);

        if (create)
        {
            DirectoryEntry rootEntry = CreateOrRecycleDirectoryEntry();
            rootEntry.RecycleRoot();
            Write(rootEntry);
        }
        else
        {
            DirectoryEntry rootEntry = GetRootEntry();

            // MS-CFB states the root storage object must be black, but the Windows Structured Storage implementation is red
#if false
            if (Context.IsStrict && rootEntry.Color is not NodeColor.Black)
                throw new FileFormatException("Root child is not black.");
#endif
        }
    }

    public void Dispose()
    {
        directoryEntryEnumerator.Dispose();
        fatChainEnumerator.Dispose();
    }

    /// <summary>
    /// Gets the <see cref="DirectoryEntry"/> for the specified stream ID.
    /// </summary>
    public DirectoryEntry GetDirectoryEntry(uint streamId)
    {
        ThrowHelper.ThrowIfDirectoryEntryStreamIdIsInvalid(streamId);

        DirectoryEntry? entry = TryGetDirectoryEntryCore(streamId);
        if (entry is null)
            ThrowHelper.ThrowDirectoryEntryNotFound(streamId);
        return entry;
    }

    /// <summary>
    /// Gets the <see cref="DirectoryEntry"/> for the root storage.
    /// </summary>
    public DirectoryEntry GetRootEntry() => GetDirectoryEntry(StreamId.Root);

    public bool TryGetDirectoryEntry(uint streamId, bool throwIfNotFound, [MaybeNullWhen(false)] out DirectoryEntry entry)
    {
        if (streamId == StreamId.NoStream)
        {
            entry = null;
            return false;
        }

        ThrowHelper.ThrowIfDirectoryEntryStreamIdIsInvalid(streamId);

        entry = TryGetDirectoryEntryCore(streamId);
        if (entry is null && throwIfNotFound)
            ThrowHelper.ThrowDirectoryEntryNotFound(streamId);
        return entry is not null;
    }

    DirectoryEntry? TryGetDirectoryEntryCore(uint streamId)
    {
        uint chainIndex = GetChainIndexAndEntryIndex(streamId, out long entryIndex);
        if (!fatChainEnumerator.MoveTo(chainIndex))
        {
            return null;
        }

        CfbBinaryReader reader = Context.Reader;
        reader.Position = fatChainEnumerator.CurrentSector.Position + (entryIndex * DirectoryEntry.Length);
        return reader.ReadDirectoryEntry(Context.Version, streamId, Context.MaxStreamLength);
    }

    public DirectoryEntry? TryGetSibling(DirectoryEntry entry, SiblingType siblingType, IDirectoryTreeValidator validator)
    {
        uint siblingId = entry.GetSiblingId(siblingType);
        if (!TryGetDirectoryEntry(siblingId, true, out DirectoryEntry? sibling))
            return null;

        validator.Validate(entry, sibling, siblingType);
        return sibling;
    }

    public DirectoryEntry GetSibling(DirectoryEntry entry, SiblingType siblingType, IDirectoryTreeValidator validator)
    {
        uint siblingId = entry.GetSiblingId(siblingType);
        DirectoryEntry sibling = GetDirectoryEntry(siblingId);
        validator.Validate(entry, sibling, siblingType);
        return sibling;
    }

    private uint GetChainIndexAndEntryIndex(uint streamId, out long entryIndex) => (uint)Math.DivRem(streamId, Context.DirectoryEntriesPerSector, out entryIndex);

    public DirectoryEntry CreateOrRecycleDirectoryEntry()
    {
        DirectoryEntry? entry = TryRecycleDirectoryEntry();
        if (entry is not null)
            return entry;

        CfbBinaryWriter writer = Context.Writer;
        uint id = fatChainEnumerator.Extend();
        Header header = Context.Header;
        if (header.FirstDirectorySectorId == SectorType.EndOfChain)
            header.FirstDirectorySectorId = id;
        if (Context.Version == Version.V4)
            header.DirectorySectorCount++;

        Sector sector = new(id, Context.SectorSize);
        writer.Position = sector.Position;
        for (int i = 0; i < Context.DirectoryEntriesPerSector; i++)
            writer.Write(DirectoryEntry.Unallocated);

        entry = TryRecycleDirectoryEntry()
            ?? throw new InvalidOperationException("Failed to add or recycle directory entry.");
        return entry;
    }

    private DirectoryEntry? TryRecycleDirectoryEntry()
    {
        directoryEntryEnumerator.Reset();

        while (directoryEntryEnumerator.MoveNext())
        {
            DirectoryEntry current = directoryEntryEnumerator.Current;
            if (current.Type is StorageType.Unallocated)
                return current;
        }

        return null;
    }

    public void Write(DirectoryEntry entry)
    {
        uint chainIndex = GetChainIndexAndEntryIndex(entry.Id, out long entryIndex);
        if (!fatChainEnumerator.MoveTo(chainIndex))
            throw new FileFormatException($"Directory entry {entry.Id} was not found.");

        CfbBinaryWriter writer = Context.Writer;
        writer.Position = fatChainEnumerator.CurrentSector.Position + (entryIndex * DirectoryEntry.Length);
        writer.Write(entry);
    }

    /// <summary>
    /// Updates the start sector and length of a stream, keeping the other fields of its <see cref="DirectoryEntry"/>,
    /// since adding or removing entries changes them.
    /// </summary>
    public void UpdateDirectoryEntry(uint streamId, uint startSectorId, long length)
    {
        DirectoryEntry entry = GetDirectoryEntry(streamId);
        entry.StartSectorId = startSectorId;
        entry.StreamLength = length;
        Write(entry);
    }

    [ExcludeFromCodeCoverage]
    public IEnumerable<DirectoryEntry> Enumerate()
    {
        using DirectoryEntryEnumerator enumerator = new(this);
        while (enumerator.MoveNext())
        {
            yield return enumerator.Current;
        }
    }

#if NET10_0_OR_GREATER
    [ExcludeFromCodeCoverage]
    public Dictionary<StorageType, int> GetStorageTypeCounts() => Enumerate()
        .CountBy(e => e.Type)
        .ToDictionary();
#endif

    [ExcludeFromCodeCoverage]
    public void Validate()
    {
        DirectoryTree tree = new(ContextSite, StreamId.Root);
        tree.Validate();
    }

    [ExcludeFromCodeCoverage]
    public void WriteTrace(TextWriter writer)
    {
        DirectoryTree tree = new(ContextSite, StreamId.Root);
        tree.WriteTrace(writer);
    }
}
